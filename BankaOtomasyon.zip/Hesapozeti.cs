﻿using System;

public class Hesapozeti
{
	public Hesapozeti()
	{

        public DateTime IslemTarihi;
    public decimal EklenenPara;
    public decimal CikanPara;
    public Musteri Kim;
    public bool IsTransfer;
}
}

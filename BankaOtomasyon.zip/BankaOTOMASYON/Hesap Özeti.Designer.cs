﻿namespace BankaOTOMASYON
{
    partial class Hesap_Özeti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.HesapNo1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.İslemTutar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.İslemTuru = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Aciklama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tarih = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HesapNo1,
            this.İslemTutar,
            this.İslemTuru,
            this.Aciklama,
            this.Tarih});
            this.dataGridView1.Location = new System.Drawing.Point(70, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(656, 335);
            this.dataGridView1.TabIndex = 0;
            // 
            // HesapNo1
            // 
            this.HesapNo1.HeaderText = "HesapNo";
            this.HesapNo1.MinimumWidth = 6;
            this.HesapNo1.Name = "HesapNo1";
            this.HesapNo1.Width = 125;
            // 
            // İslemTutar
            // 
            this.İslemTutar.HeaderText = "İşlem Tutarı";
            this.İslemTutar.MinimumWidth = 6;
            this.İslemTutar.Name = "İslemTutar";
            this.İslemTutar.Width = 125;
            // 
            // İslemTuru
            // 
            this.İslemTuru.HeaderText = "İşlem Türü";
            this.İslemTuru.MinimumWidth = 6;
            this.İslemTuru.Name = "İslemTuru";
            this.İslemTuru.Width = 125;
            // 
            // Aciklama
            // 
            this.Aciklama.HeaderText = "Açıklama";
            this.Aciklama.MinimumWidth = 6;
            this.Aciklama.Name = "Aciklama";
            this.Aciklama.Width = 125;
            // 
            // Tarih
            // 
            this.Tarih.HeaderText = "Tarih";
            this.Tarih.MinimumWidth = 6;
            this.Tarih.Name = "Tarih";
            this.Tarih.Width = 125;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(276, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "HESAP ÖZETİ";
            // 
            // Hesap_Özeti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Hesap_Özeti";
            this.Text = "Hesap_Özeti";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn HesapNo1;
        private DataGridViewTextBoxColumn İslemTutar;
        private DataGridViewTextBoxColumn İslemTuru;
        private DataGridViewTextBoxColumn Aciklama;
        private DataGridViewTextBoxColumn Tarih;
        private Label label1;
    }
}
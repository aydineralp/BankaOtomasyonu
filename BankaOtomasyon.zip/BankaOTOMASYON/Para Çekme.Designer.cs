﻿namespace BankaOTOMASYON
{
    partial class Para_Çekme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CekBtn20 = new System.Windows.Forms.Button();
            this.CekBtn200 = new System.Windows.Forms.Button();
            this.CekBtn50 = new System.Windows.Forms.Button();
            this.CekBtnHepsi = new System.Windows.Forms.Button();
            this.CekBtn100 = new System.Windows.Forms.Button();
            this.CekBtnDiger = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CekBtn20
            // 
            this.CekBtn20.Location = new System.Drawing.Point(103, 77);
            this.CekBtn20.Name = "CekBtn20";
            this.CekBtn20.Size = new System.Drawing.Size(94, 29);
            this.CekBtn20.TabIndex = 0;
            this.CekBtn20.Text = "20";
            this.CekBtn20.UseVisualStyleBackColor = true;
            // 
            // CekBtn200
            // 
            this.CekBtn200.Location = new System.Drawing.Point(222, 77);
            this.CekBtn200.Name = "CekBtn200";
            this.CekBtn200.Size = new System.Drawing.Size(94, 29);
            this.CekBtn200.TabIndex = 1;
            this.CekBtn200.Text = "200";
            this.CekBtn200.UseVisualStyleBackColor = true;
            // 
            // CekBtn50
            // 
            this.CekBtn50.Location = new System.Drawing.Point(103, 127);
            this.CekBtn50.Name = "CekBtn50";
            this.CekBtn50.Size = new System.Drawing.Size(94, 29);
            this.CekBtn50.TabIndex = 2;
            this.CekBtn50.Text = "50";
            this.CekBtn50.UseVisualStyleBackColor = true;
            // 
            // CekBtnHepsi
            // 
            this.CekBtnHepsi.Location = new System.Drawing.Point(222, 127);
            this.CekBtnHepsi.Name = "CekBtnHepsi";
            this.CekBtnHepsi.Size = new System.Drawing.Size(94, 29);
            this.CekBtnHepsi.TabIndex = 3;
            this.CekBtnHepsi.Text = "Hepsi";
            this.CekBtnHepsi.UseVisualStyleBackColor = true;
            // 
            // CekBtn100
            // 
            this.CekBtn100.Location = new System.Drawing.Point(104, 176);
            this.CekBtn100.Name = "CekBtn100";
            this.CekBtn100.Size = new System.Drawing.Size(94, 29);
            this.CekBtn100.TabIndex = 4;
            this.CekBtn100.Text = "100";
            this.CekBtn100.UseVisualStyleBackColor = true;
            // 
            // CekBtnDiger
            // 
            this.CekBtnDiger.Location = new System.Drawing.Point(222, 227);
            this.CekBtnDiger.Name = "CekBtnDiger";
            this.CekBtnDiger.Size = new System.Drawing.Size(94, 29);
            this.CekBtnDiger.TabIndex = 5;
            this.CekBtnDiger.Text = "Diğer";
            this.CekBtnDiger.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(278, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 26);
            this.label1.TabIndex = 6;
            this.label1.Text = "PARA ÇEKME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label2.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 26);
            this.label2.TabIndex = 7;
            this.label2.Text = "Güncel Bakiyeniz:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.CekBtn200);
            this.groupBox1.Controls.Add(this.CekBtn20);
            this.groupBox1.Controls.Add(this.CekBtn100);
            this.groupBox1.Controls.Add(this.CekBtnHepsi);
            this.groupBox1.Controls.Add(this.CekBtn50);
            this.groupBox1.Controls.Add(this.CekBtnDiger);
            this.groupBox1.Location = new System.Drawing.Point(163, 114);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(414, 274);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tutar";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(104, 228);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(94, 27);
            this.textBox1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tutar Giriniz:";
            // 
            // Para_Çekme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Para_Çekme";
            this.Text = "Para_Çekme";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button CekBtn20;
        private Button CekBtn200;
        private Button CekBtn50;
        private Button CekBtnHepsi;
        private Button CekBtn100;
        private Button CekBtnDiger;
        private Label label1;
        private Label label2;
        private GroupBox groupBox1;
        private Label label3;
        private TextBox textBox1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankaOTOMASYON
{
    public partial class Müşteri_Ana_Ekran : Form
    {
        public Müşteri_Ana_Ekran()
        {
            InitializeComponent();
        }

        private void paraÇekmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Para_Çekme para_Çekme = new Para_Çekme();
            para_Çekme.Show();
        }

        private void paraYatırmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Para_Yatırma para_Yatırma = new Para_Yatırma();
            para_Yatırma.Show();

        }

        private void hesabaHavaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hesaba_Havale hesaba_Havale = new Hesaba_Havale();
            hesaba_Havale.Show();
        }

        private void bankaGelirGiderRaporuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Gelir_Gider_Raporu gelir_Gider_Raporu = new Gelir_Gider_Raporu();
            gelir_Gider_Raporu.Show();
        }

        private void hesapÖzetiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hesap_Özeti hesap_Özeti = new Hesap_Özeti();
            hesap_Özeti.Show();
        }

        private void hesapKapamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Hesap_Kapama hesap_Kapama = new Hesap_Kapama();
            hesap_Kapama.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankaOTOMASYON
{
    public partial class Gelir_Gider_Raporu : Form
    {
        public Gelir_Gider_Raporu()
        {
            InitializeComponent();
        }
    }
}

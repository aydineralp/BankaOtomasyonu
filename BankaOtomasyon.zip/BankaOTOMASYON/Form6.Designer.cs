﻿namespace BankaOTOMASYON
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.paraÇekmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paraYatırmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesabaHavaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaGelirGiderRaporuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesapÖzetiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesapKapamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paraÇekmeToolStripMenuItem,
            this.paraYatırmaToolStripMenuItem,
            this.hesabaHavaleToolStripMenuItem,
            this.bankaGelirGiderRaporuToolStripMenuItem,
            this.hesapÖzetiToolStripMenuItem,
            this.hesapKapamaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // paraÇekmeToolStripMenuItem
            // 
            this.paraÇekmeToolStripMenuItem.Name = "paraÇekmeToolStripMenuItem";
            this.paraÇekmeToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.paraÇekmeToolStripMenuItem.Text = "Para Çekme";
            this.paraÇekmeToolStripMenuItem.Click += new System.EventHandler(this.paraÇekmeToolStripMenuItem_Click);
            // 
            // paraYatırmaToolStripMenuItem
            // 
            this.paraYatırmaToolStripMenuItem.Name = "paraYatırmaToolStripMenuItem";
            this.paraYatırmaToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
            this.paraYatırmaToolStripMenuItem.Text = "Para Yatırma";
            // 
            // hesabaHavaleToolStripMenuItem
            // 
            this.hesabaHavaleToolStripMenuItem.Name = "hesabaHavaleToolStripMenuItem";
            this.hesabaHavaleToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
            this.hesabaHavaleToolStripMenuItem.Text = "Hesaba Havale";
            // 
            // bankaGelirGiderRaporuToolStripMenuItem
            // 
            this.bankaGelirGiderRaporuToolStripMenuItem.Name = "bankaGelirGiderRaporuToolStripMenuItem";
            this.bankaGelirGiderRaporuToolStripMenuItem.Size = new System.Drawing.Size(196, 24);
            this.bankaGelirGiderRaporuToolStripMenuItem.Text = "Banka Gelir-Gider Raporu ";
            // 
            // hesapÖzetiToolStripMenuItem
            // 
            this.hesapÖzetiToolStripMenuItem.Name = "hesapÖzetiToolStripMenuItem";
            this.hesapÖzetiToolStripMenuItem.Size = new System.Drawing.Size(104, 24);
            this.hesapÖzetiToolStripMenuItem.Text = "Hesap Özeti";
            // 
            // hesapKapamaToolStripMenuItem
            // 
            this.hesapKapamaToolStripMenuItem.Name = "hesapKapamaToolStripMenuItem";
            this.hesapKapamaToolStripMenuItem.Size = new System.Drawing.Size(124, 24);
            this.hesapKapamaToolStripMenuItem.Text = "Hesap Kapama";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(242, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 26);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ticari Müşteri Ana Ekranı";
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem paraÇekmeToolStripMenuItem;
        private ToolStripMenuItem paraYatırmaToolStripMenuItem;
        private ToolStripMenuItem hesabaHavaleToolStripMenuItem;
        private ToolStripMenuItem bankaGelirGiderRaporuToolStripMenuItem;
        private ToolStripMenuItem hesapÖzetiToolStripMenuItem;
        private ToolStripMenuItem hesapKapamaToolStripMenuItem;
        private Label label1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankaOTOMASYON
{
    public partial class TicariGiris : Form
    {
        public TicariGiris()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kullanici_adi = textBox1.Text;
            int sifre = int.Parse(textBox2.Text);
            if (kullanici_adi.Length == 0)
            {
                MessageBox.Show("bu alan boş bırakılmamalıdır!");
            }

            Müşteri_Ana_Ekran müşteri_Ana_Ekran = new Müşteri_Ana_Ekran();
            müşteri_Ana_Ekran.Show();
        }

        private void TicariGiris_Load(object sender, EventArgs e)
        {

        }
    }
}

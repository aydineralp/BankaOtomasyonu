﻿namespace BankaOTOMASYON
{
    partial class Müşteri_Ana_Ekran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.paraÇekmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paraYatırmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesabaHavaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankaGelirGiderRaporuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesapÖzetiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesapKapamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paraÇekmeToolStripMenuItem,
            this.paraYatırmaToolStripMenuItem,
            this.hesabaHavaleToolStripMenuItem,
            this.bankaGelirGiderRaporuToolStripMenuItem,
            this.hesapÖzetiToolStripMenuItem,
            this.hesapKapamaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // paraÇekmeToolStripMenuItem
            // 
            this.paraÇekmeToolStripMenuItem.Name = "paraÇekmeToolStripMenuItem";
            this.paraÇekmeToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.paraÇekmeToolStripMenuItem.Text = "Para Çekme";
            this.paraÇekmeToolStripMenuItem.Click += new System.EventHandler(this.paraÇekmeToolStripMenuItem_Click);
            // 
            // paraYatırmaToolStripMenuItem
            // 
            this.paraYatırmaToolStripMenuItem.Name = "paraYatırmaToolStripMenuItem";
            this.paraYatırmaToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
            this.paraYatırmaToolStripMenuItem.Text = "Para Yatırma";
            this.paraYatırmaToolStripMenuItem.Click += new System.EventHandler(this.paraYatırmaToolStripMenuItem_Click);
            // 
            // hesabaHavaleToolStripMenuItem
            // 
            this.hesabaHavaleToolStripMenuItem.Name = "hesabaHavaleToolStripMenuItem";
            this.hesabaHavaleToolStripMenuItem.Size = new System.Drawing.Size(123, 24);
            this.hesabaHavaleToolStripMenuItem.Text = "Hesaba Havale";
            this.hesabaHavaleToolStripMenuItem.Click += new System.EventHandler(this.hesabaHavaleToolStripMenuItem_Click);
            // 
            // bankaGelirGiderRaporuToolStripMenuItem
            // 
            this.bankaGelirGiderRaporuToolStripMenuItem.Name = "bankaGelirGiderRaporuToolStripMenuItem";
            this.bankaGelirGiderRaporuToolStripMenuItem.Size = new System.Drawing.Size(196, 24);
            this.bankaGelirGiderRaporuToolStripMenuItem.Text = "Banka Gelir-Gider Raporu ";
            this.bankaGelirGiderRaporuToolStripMenuItem.Click += new System.EventHandler(this.bankaGelirGiderRaporuToolStripMenuItem_Click);
            // 
            // hesapÖzetiToolStripMenuItem
            // 
            this.hesapÖzetiToolStripMenuItem.Name = "hesapÖzetiToolStripMenuItem";
            this.hesapÖzetiToolStripMenuItem.Size = new System.Drawing.Size(104, 24);
            this.hesapÖzetiToolStripMenuItem.Text = "Hesap Özeti";
            this.hesapÖzetiToolStripMenuItem.Click += new System.EventHandler(this.hesapÖzetiToolStripMenuItem_Click);
            // 
            // hesapKapamaToolStripMenuItem
            // 
            this.hesapKapamaToolStripMenuItem.Name = "hesapKapamaToolStripMenuItem";
            this.hesapKapamaToolStripMenuItem.Size = new System.Drawing.Size(124, 24);
            this.hesapKapamaToolStripMenuItem.Text = "Hesap Kapama";
            this.hesapKapamaToolStripMenuItem.Click += new System.EventHandler(this.hesapKapamaToolStripMenuItem_Click);
            // 
            // Müşteri_Ana_Ekran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Müşteri_Ana_Ekran";
            this.Text = "Müşteri_Ana_Ekran";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem paraÇekmeToolStripMenuItem;
        private ToolStripMenuItem paraYatırmaToolStripMenuItem;
        private ToolStripMenuItem hesabaHavaleToolStripMenuItem;
        private ToolStripMenuItem bankaGelirGiderRaporuToolStripMenuItem;
        private ToolStripMenuItem hesapÖzetiToolStripMenuItem;
        private ToolStripMenuItem hesapKapamaToolStripMenuItem;
    }
}